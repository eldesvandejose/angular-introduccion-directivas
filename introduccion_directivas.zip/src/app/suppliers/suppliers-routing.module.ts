import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SuppliersListComponent } from './suppliers-list/suppliers-list.component';
import { SupplierDataComponent } from './supplier-data/supplier-data.component';
import { SupplierEditComponent } from './supplier-edit/supplier-edit.component';

const routes: Routes = [
  {
    path: '',
    component: SuppliersListComponent
  },
  {
    path: 'ver_proveedor/:id',
    component: SupplierDataComponent
  },
  {
    path: 'editar_proveedor/:id',
    component: SupplierEditComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SuppliersRoutingModule { }
