import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-suppliers-list',
  templateUrl: './suppliers-list.component.html',
  styleUrls: ['./suppliers-list.component.css']
})
export class SuppliersListComponent implements OnInit {

  constructor() {}

  ngOnInit() {}
}
