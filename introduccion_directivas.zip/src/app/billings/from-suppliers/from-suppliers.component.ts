import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-from-suppliers',
  templateUrl: './from-suppliers.component.html',
  styleUrls: ['./from-suppliers.component.css']
})
export class FromSuppliersComponent implements OnInit {

  constructor() {}

  ngOnInit() {}
}
